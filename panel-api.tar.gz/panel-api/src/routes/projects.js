const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const fs = require('fs').promises;
const path = require('path');

// Get all projects
router.get('/', async (req, res, next) => {
  try {
    const { rows } = await req.app.locals.db.query(
      'SELECT * FROM projects ORDER BY created_at DESC'
    );
    res.json({ projects: rows });
  } catch (error) {
    next(error);
  }
});

// Get project by ID
router.get('/:id', async (req, res, next) => {
  try {
    const { rows } = await req.app.locals.db.query(
      'SELECT * FROM projects WHERE id = $1',
      [req.params.id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: { message: 'Project not found' } });
    }
    
    res.json({ project: rows[0] });
  } catch (error) {
    next(error);
  }
});

// Create new project
router.post('/', async (req, res, next) => {
  try {
    const { name, description, type, duration, reference } = req.body;
    
    // Validate required fields
    if (!name || !type) {
      return res.status(400).json({ 
        error: { message: 'Name and type are required' } 
      });
    }
    
    const projectId = uuidv4();
    
    // Create project directory structure
    const projectPath = path.join('/data/video_factory', projectId);
    const dirs = [
      'characters',
      'reference',
      'roteiro',
      'prompts',
      'imagens',
      'videos',
      'frames_extraidos',
      'audio',
      'musica',
      'edicao',
      'export'
    ];
    
    for (const dir of dirs) {
      await fs.mkdir(path.join(projectPath, dir), { recursive: true });
    }
    
    // Initialize manifest
    const manifest = {
      version: '1.0',
      projectId,
      name,
      type,
      duration,
      reference,
      status: 'draft',
      scenes: [],
      characters: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    // Save manifest to file
    await fs.writeFile(
      path.join(projectPath, 'manifest.json'),
      JSON.stringify(manifest, null, 2)
    );
    
    // Insert into database
    const { rows } = await req.app.locals.db.query(
      `INSERT INTO projects (id, name, description, type, duration, status, manifest)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [projectId, name, description, type, duration, 'draft', manifest]
    );
    
    // Publish event to Redis
    await req.app.locals.redis.publish('agent-events', JSON.stringify({
      type: 'project.created',
      projectId,
      timestamp: new Date().toISOString()
    }));
    
    res.status(201).json({ project: rows[0] });
  } catch (error) {
    next(error);
  }
});

// Update project
router.put('/:id', async (req, res, next) => {
  try {
    const { name, description, status, manifest } = req.body;
    
    const { rows } = await req.app.locals.db.query(
      `UPDATE projects 
       SET name = COALESCE($1, name),
           description = COALESCE($2, description),
           status = COALESCE($3, status),
           manifest = COALESCE($4, manifest),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $5
       RETURNING *`,
      [name, description, status, manifest, req.params.id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: { message: 'Project not found' } });
    }
    
    // Update manifest file
    if (manifest) {
      const projectPath = path.join('/data/video_factory', req.params.id);
      await fs.writeFile(
        path.join(projectPath, 'manifest.json'),
        JSON.stringify(manifest, null, 2)
      );
    }
    
    // Publish event
    await req.app.locals.redis.publish('agent-events', JSON.stringify({
      type: 'project.updated',
      projectId: req.params.id,
      timestamp: new Date().toISOString()
    }));
    
    res.json({ project: rows[0] });
  } catch (error) {
    next(error);
  }
});

// Delete project
router.delete('/:id', async (req, res, next) => {
  try {
    const { rows } = await req.app.locals.db.query(
      'DELETE FROM projects WHERE id = $1 RETURNING *',
      [req.params.id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: { message: 'Project not found' } });
    }
    
    // Delete project directory
    const projectPath = path.join('/data/video_factory', req.params.id);
    await fs.rm(projectPath, { recursive: true, force: true });
    
    // Publish event
    await req.app.locals.redis.publish('agent-events', JSON.stringify({
      type: 'project.deleted',
      projectId: req.params.id,
      timestamp: new Date().toISOString()
    }));
    
    res.json({ message: 'Project deleted successfully' });
  } catch (error) {
    next(error);
  }
});

// Download project video
router.get('/:id/download', async (req, res, next) => {
  try {
    const projectPath = path.join('/data/video_factory', req.params.id);
    const videoPath = path.join(projectPath, 'export', 'final_video.mp4');
    
    // Check if file exists
    try {
      await fs.access(videoPath);
    } catch (err) {
      return res.status(404).json({ 
        error: { 
          message: 'Vídeo não encontrado. O arquivo pode estar em processamento ou o projeto não foi concluído.',
          path: videoPath
        } 
      });
    }
    
    // Send file for download
    res.download(videoPath, `projeto-${req.params.id}.mp4`, (err) => {
      if (err) {
        console.error('Download error:', err);
        if (!res.headersSent) {
          res.status(500).json({ error: { message: 'Erro ao baixar arquivo' } });
        }
      }
    });
  } catch (error) {
    next(error);
  }
});

// Start project execution
router.post('/:id/execute', async (req, res, next) => {
  try {
    const { sceneId } = req.body;
    
    // Update project status
    await req.app.locals.db.query(
      'UPDATE projects SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
      ['executing', req.params.id]
    );
    
    // Queue execution task
    await req.app.locals.redis.lpush('execution-queue', JSON.stringify({
      projectId: req.params.id,
      sceneId: sceneId || 'all',
      timestamp: new Date().toISOString()
    }));
    
    // Publish event
    await req.app.locals.redis.publish('agent-events', JSON.stringify({
      type: 'execution.started',
      projectId: req.params.id,
      sceneId,
      timestamp: new Date().toISOString()
    }));
    
    res.json({ 
      message: 'Execution started',
      projectId: req.params.id,
      sceneId
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
